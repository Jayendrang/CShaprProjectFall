﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsignmentCompanyProject.com.app.dataobjects
{
    /*
     * created by Jayendran Gurumoorthy
     * */

    // This class holds manufacturer information for inventory managament and order module

    class ManufacturerProperties
    {
        public string Manufacturer_Id { get; set; }
        public string Manufacturer_Name { get; set; }
        public string Manufacturer_Detail {  set;  get; }
        public string Manufacturer_Status { set; get; }
       
        
    }
}
